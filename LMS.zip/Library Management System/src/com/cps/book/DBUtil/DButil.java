package com.cps.book.DBUtil;

import java.util.HashMap;

import com.cps.book.bean.book;

public class DButil
{
	HashMap<Integer,book>hmap=new HashMap<Integer,book>();

	public void addEnquiry(book beanbook)
	{
		hmap.put(book.getbNumber(),beanbook);
		
				
	}

	public book searchBook(int booknumber) 
	{
		if(hmap.containsKey(booknumber))
		{
			return hmap.get(booknumber);
		}
		return null;
	}

	public HashMap<Integer, book> viewBook() {
		
		return hmap;
	}
	public boolean validateName(String bname)
	{
		return false;
	}
	
	
	
	
}
