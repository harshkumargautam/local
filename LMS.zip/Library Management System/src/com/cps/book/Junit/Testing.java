package com.cps.book.Junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cps.book.bean.book;
import com.cps.book.dao.BookDaoImpl;
import com.cps.book.service.bookException;

public class Testing {
	static BookDaoImpl bookDao=new BookDaoImpl();
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void  viewBook() throws bookException
	{
		//new book("Harsh", "Cdddd","4444","1997",111);
		Assert.assertNotNull(bookDao.viewBook());
		
		
	}

	@Test
	public void  addEnquiry()
	{
		
		Assert.assertEquals(111, bookDao.addEnquiry(new book("Harsh", "Cdddd","4444","1997",111)));
		
		
	}
	
}
