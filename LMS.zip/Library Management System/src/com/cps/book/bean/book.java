package com.cps.book.bean;

public class book
{
	String bookName;
	String authorName;
	String edition;
	String year;
	static int bNumber;
	public book(String bookName, String authorName, String edition, String year, int bNumber) {
		super();
		this.bookName = bookName;
		this.authorName = authorName;
		this.edition = edition;
		this.year = year;
		this.bNumber = bNumber;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public String getEdition() {
		return edition;
	}
	public void setEdition(String edition) {
		this.edition = edition;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public static int getbNumber() {
		return bNumber;
	}
	public void setbNumber(int bNumber) {
		this.bNumber = bNumber;
	}
	@Override
	public String toString() {
		return "[Book Name= "+bookName+"\tAuthorName= "+authorName+"\tEdition= "+edition+"\tYear= "+year
				+"\tBook Number= "+bNumber+"]";
	}
}