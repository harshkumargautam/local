package com.cps.book.dao;

import java.util.HashMap;
import java.util.HashSet;


import com.cps.book.bean.book;
import com.cps.book.service.bookException;

public interface BookDao 
{
	public int addEnquiry(book beanbook) throws bookException;
	public book searchBook(int beanbook)throws bookException;
	public HashMap<Integer,book> viewBook()throws bookException;
	public boolean validateName(String bname)throws bookException;
	public boolean validateAuthorName(String aname)throws bookException;
	public boolean validateYear(String year)throws bookException;
	public boolean validateEdition(String publication)throws bookException;
	public boolean validateBookNumber(int bNo)throws bookException;
	
	  
}
