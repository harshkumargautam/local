package com.cps.book.dao;

import java.util.HashMap;

import com.cps.book.DBUtil.DButil;
import com.cps.book.bean.book;
import com.cps.book.service.bookException;

public class BookDaoImpl implements BookDao{

	DButil dbutil=new DButil();
	
	@Override
	public int addEnquiry(book beanbook) {
	
		dbutil.addEnquiry(beanbook);
		return beanbook.getbNumber();
	}

	@Override
	public book searchBook(int booknumber) throws bookException {
		// TODO Auto-generated method stub
		return dbutil.searchBook(booknumber);
	}

	@Override
	public HashMap<Integer, book> viewBook() throws bookException {
		
		return dbutil.viewBook();
	}

	@Override
	public boolean validateName(String bname) throws bookException {
		
		return false;
	}

	@Override
	public boolean validateAuthorName(String aname) throws bookException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateYear(String year) throws bookException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateEdition(String publication) throws bookException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateBookNumber(int bNo) throws bookException {
		// TODO Auto-generated method stub
		return false;
	}

}
