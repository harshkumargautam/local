package com.cps.book.service;

import java.util.HashMap;
import java.util.HashSet;

import com.cps.book.bean.*;
import com.cps.book.bean.book;

public interface BookService
{
	public int addEnquiry(book beanbook)throws bookException;
	public book searchBook(int beanbook)throws bookException;
	public HashMap<Integer,book>viewBook()throws bookException;
	public boolean validateName(String bname)throws bookException;
	public boolean validateAuthorName(String aname)throws bookException;
	public boolean validateYear(String year)throws bookException;
	public boolean validateEdition(String publication)throws bookException;
	public boolean validateBookNumber(int bNo) throws bookException;
	
}
