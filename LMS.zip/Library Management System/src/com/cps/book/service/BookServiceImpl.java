package com.cps.book.service;

import java.util.HashMap;
import java.util.regex.Pattern;

import com.cps.book.bean.book;
import com.cps.book.dao.BookDao;
import com.cps.book.dao.BookDaoImpl;

public class BookServiceImpl implements BookService
{

	BookDaoImpl daobook=new BookDaoImpl();
	@Override
	public int addEnquiry(book beanbook) {
		daobook.addEnquiry(beanbook);
		return daobook.addEnquiry(beanbook);
	}
	@Override
	public book searchBook(int booknumber) throws bookException {
		// TODO Auto-generated method stub
		return daobook.searchBook(booknumber);
	}
	@Override
	public HashMap<Integer, book> viewBook() throws bookException {
		
		return daobook.viewBook();
	}
	
	@Override
	public boolean validateName(String bname) throws bookException
	{
	        String namePatter="[A-Z][a-z]+{8}";
	        if(bname!= null)
	        {
	        	if(Pattern.matches(namePatter, bname))
	        	{
	        		return true;
	        	}
	        	else
	        	{
	        		throw new bookException ("Name Should be start with capital Letter & should be less than 8 characters");
	        	}
	        }
	        else
	        {
	        	System.out.println("Cannot be Null");
	        	return false;
	        }
	}
	@Override
	public boolean validateAuthorName(String aname) throws bookException
	{
		String namePatter="[A-Z][a-z]+{8}";
		if(aname==null)
        {
        	throw new bookException("Cannot be Null");
        }
        if(Pattern.matches(namePatter, aname))
        {
            return true;
        }
        else
        {
        	throw new bookException("Author Name Should be Start With Capital Letters & should be less than 8 characters");
        }
	

		
	}
	@Override
	public boolean validateYear(String year) throws bookException
	{
		 String digitPatter="[0-9]+{4}";
	        if(Pattern.matches(digitPatter, year))
	        {
	            return true;
	        }
	        else
	        {
	        	throw new bookException("Only Limited to 4 digits");
	        }

	}
	@Override
	public boolean validateEdition(String publication) throws bookException
	{
		String digitPattern="[0-9]+{4}";
		if(Pattern.matches(digitPattern, publication))
		{
			return true;
		}
		else
		{
			throw new bookException("Only Limited to 4 digits");
			
		}
	
	}
	@Override
	public boolean validateBookNumber(int bNo) throws bookException
	{
		
		return true;
	}
	

	

}
