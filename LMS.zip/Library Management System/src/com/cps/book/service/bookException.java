package com.cps.book.service;

public class bookException extends Exception 
{
	public bookException(String msg)
	{
		super(msg);
	}
}
