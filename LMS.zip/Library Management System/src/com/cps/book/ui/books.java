package com.cps.book.ui;

import java.awt.print.Book;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.Map; 
import java.util.HashMap; 

import javax.swing.text.TableView;

import java.util.Iterator;

import com.cps.book.bean.book;
import com.cps.book.service.BookServiceImpl;
import com.cps.book.service.bookException;
import com.cps.book.DBUtil.*;
public class books {
	static Scanner sc=new Scanner(System.in);
	static BookServiceImpl bookser=new BookServiceImpl();
	public static void main(String[] args) throws bookException
	{
		while(true)
		{
			System.out.println("Welcome to Library Management System");
			System.out.println("Enter choice");
			System.out.println("1.Add Book to the library");
			System.out.println("2.Search Book in the library");
			System.out.println("3.View All Books in the Library");
			System.out.println("0.Exit");
			int choice=sc.nextInt();
			operations(choice);
		}
	}
	public static void operations(int choice) throws bookException {
		switch(choice)
		{
		case 1:addBook();break;
		case 2:searchBook();break;
		case 3:viewBook();break;
		default: System.exit(0);
		}

	}
	private static void viewBook() throws bookException
	{


		HashMap<Integer,book>hmap=bookser.viewBook();
		for(Map.Entry<Integer, book>all:hmap.entrySet())
		{
			//System.out.println(all.getKey());
			System.out.println(all.getValue());



		}




	}
	private static void searchBook() {

		System.out.println("Enter Book Number");
		int search=sc.nextInt();
		try
		{
			book googleSearch=bookser.searchBook(search);
			//System.out.println(bookser.searchBook(search));
			if(googleSearch!=null)
			{
				System.out.println(googleSearch);
			}
			else
			{
				System.out.println("Book Not Found... Try Again With Correct Book Number");
			}
		} 
		catch (bookException e)
		{

		}

	}
	private static void addBook() throws bookException
	{
		Random r=new Random();
		while(true)
		{
			System.out.println("Enter Book Name");
			String bName=sc.next();
			try
			{
				if(bookser.validateName(bName))
				{
					while(true)
					{
						try
						{
							System.out.println("Enter Author Name");
							String aName=sc.next();
							if(bookser.validateAuthorName(aName))
							{
								while(true)
								{
									try
									{
										System.out.println("Enter edition");
										String edition=sc.next();
										if(bookser.validateEdition(edition))
										{
											while (true)
											{
												try
												{
													System.out.println("Enter Year of Pulication");
													String year=sc.next();
													if(bookser.validateYear(year))
													{
														while(true)
														{
															try
															{
																System.out.println("Enter Book Number");
																int bNo=sc.nextInt();
																if(bookser.validateBookNumber(bNo))
																{//while(true)
																	{

																		book beanbook= new book(bName, aName, edition, year, bNo);
																		int e=bookser.addEnquiry(beanbook);
																		System.out.println("Thanks Book Entered Successfully");
																		System.out.println("Book Details added are :");
																		System.out.println("Book Name : "+bName);
																		System.out.println("Author : "+aName);
																		System.out.println("Edition : "+edition);
																		System.out.println("Year of Publication : "+year);
																		System.out.println("Book Number : "+bNo);
																		System.out.println("********************************************");
																	}
																}//break;
															break;}
															catch(bookException e)
															{
																System.out.println(e.getMessage());
															}

														}
													}
										break;		}
												catch(bookException e)
												{
													System.out.println(e.getMessage());
												}
											}
										}
								break;	}
									catch(bookException e)

									{
										System.out.println(e.getMessage());
									}
								}
							}
						break;}
						catch(bookException e)
						{
							System.out.println(e.getMessage());
						}
					}
				}
		break;	}
			catch(bookException e)
			{
				System.out.println(e.getMessage());

			}
		}
	}
}
